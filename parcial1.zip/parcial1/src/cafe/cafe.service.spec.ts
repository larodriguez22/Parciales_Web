import { Test, TestingModule } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { TypeOrmTestingConfig } from '../shared/testing-utils/typeorm-testing-config';
import { faker } from '@faker-js/faker';

import { Repository } from 'typeorm';
import { CafeEntity } from './cafe.entity';
import { CafeService } from './cafe.service';
import { TiendaEntity } from '../tienda/tienda.entity';

describe('CafeService', () => {
  let service: CafeService;
  let repository: Repository<CafeEntity>;
  let cafesList: CafeEntity[];
  let tienda: TiendaEntity;
  let persitedTienda: TiendaEntity;
  let tiendaRepository: Repository<TiendaEntity>;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports: [...TypeOrmTestingConfig()],
      providers: [CafeService],
    }).compile();

    service = module.get<CafeService>(CafeService);
    repository = module.get<Repository<CafeEntity>>(
      getRepositoryToken(CafeEntity),
    );
    tiendaRepository = module.get<Repository<TiendaEntity>>(
      getRepositoryToken(TiendaEntity),
    );
    await seedDatabase();
  });

  const seedDatabase = async () => {
    repository.clear();
    cafesList = [];

    const tienda: TiendaEntity = {
      id: '',
      nombre: faker.company.name(),
      direccion: faker.address.streetAddress(),
      telefono: faker.phone.phoneNumber(),
      cafes: [],
    };

    persitedTienda = await tiendaRepository.save(tienda);


    for (let i = 0; i < 5; i++) {
      const cafe: CafeEntity = await repository.save({
        nombre: faker.commerce.productName(),
        precio: faker.datatype.number({ min: 50, max: 10000000 }),
        tienda: tienda
      });
      cafesList.push(cafe);
    }
  };

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('create should return a new cafe', async () => {
    const cafe: CafeEntity = {
      id: "",
      nombre: faker.commerce.productName(),
      precio: faker.datatype.number({ min: 50, max: 10000000 }),
      tienda: tienda
    }

    const newCafe: CafeEntity = await service.create(cafe);
    expect(newCafe).not.toBeNull();

    const storedCafe: CafeEntity = await service.findOne(newCafe.id);
    expect(storedCafe).not.toBeNull();
    expect(storedCafe.nombre).toEqual(newCafe.nombre);
    expect(storedCafe.precio).toEqual(newCafe.precio);
  });
});
