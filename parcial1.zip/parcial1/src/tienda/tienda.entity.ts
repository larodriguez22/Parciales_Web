import { CafeEntity } from '../cafe/cafe.entity';
import { Column, Entity, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
@Entity()
export class TiendaEntity {
    @PrimaryGeneratedColumn('uuid')
    id: string;

    @Column()
    nombre: String;

    @Column()
    direccion: String;

    @Column()
    telefono: String;

    @OneToMany(() => CafeEntity, (cafes) => cafes.tienda)
    cafes: CafeEntity[];
}
